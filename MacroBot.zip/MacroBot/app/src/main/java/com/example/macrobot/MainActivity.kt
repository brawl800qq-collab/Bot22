package com.example.macrobot

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f, color: String = "#9FB0C8") = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.parseColor(color))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0F111A")
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(30)) }
        col.addView(label("⚡ Макро-бот", 26f, "#FFFFFF"))
        col.addView(label("Записывает твои действия и повторяет. Без ИИ, без интернета, без лимитов."))
        status = label("", 15f, "#FFFFFF")
        col.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        col.addView(TextView(this).apply {
            text = "Включить службу"; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply { setColor(Color.parseColor("#00B894")); cornerRadius = dp(14).toFloat() }
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        col.addView(label(
            "Как пользоваться:\n" +
            "1. Настройки → Специальные возможности → Макро-бот → Включить.\n" +
            "2. Появится окно ⚡. Открой нужное приложение или игру.\n" +
            "3. ⏺ Запись → делай тапы и свайпы → ⏹.\n" +
            "4. Поставь «Повторов» (0 = бесконечно) и жми ▶ Играть.\n" +
            "5. 💾 сохраняет сценарий, 📂 — список (удержание = удалить).\n\n" +
            "+ клик по тексту — бот сам найдёт кнопку по надписи, даже если она сдвинулась.\n" +
            "🎲 рандом — случайные паузы и смещение тапов.\n\n" +
            "Infinix/XOS: Настройки → Приложения → Макро-бот → Батарея → «Без ограничений»."
        ), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0F111A")); addView(col) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (MacroService.instance != null) "✅ Служба включена — окно на экране" else "⚠️ Служба выключена"
    }
}
