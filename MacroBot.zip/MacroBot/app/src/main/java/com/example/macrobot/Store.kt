package com.example.macrobot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Координаты хранятся долями экрана (0..1), поэтому сценарий не зависит от разрешения. */
data class Step(
    val type: String,            // tap | swipe | back | home | wait | text
    val x1: Float = 0f, val y1: Float = 0f,
    val x2: Float = 0f, val y2: Float = 0f,
    val dur: Long = 50,          // длительность жеста / ожидание / таймаут поиска текста
    val delay: Long = 0,         // пауза ПЕРЕД шагом
    val text: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("t", type).put("x1", x1.toDouble()).put("y1", y1.toDouble())
        .put("x2", x2.toDouble()).put("y2", y2.toDouble())
        .put("d", dur).put("p", delay).put("s", text)

    companion object {
        fun fromJson(o: JSONObject) = Step(
            o.optString("t"), o.optDouble("x1", 0.0).toFloat(), o.optDouble("y1", 0.0).toFloat(),
            o.optDouble("x2", 0.0).toFloat(), o.optDouble("y2", 0.0).toFloat(),
            o.optLong("d", 50), o.optLong("p", 0), o.optString("s")
        )
    }
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("macros", Context.MODE_PRIVATE)
    private fun all(c: Context) = JSONObject(prefs(c).getString("all", "{}") ?: "{}")

    fun names(c: Context): List<String> = all(c).keys().asSequence().toList().sorted()

    fun save(c: Context, name: String, steps: List<Step>) {
        val arr = JSONArray()
        steps.forEach { arr.put(it.toJson()) }
        val o = all(c).put(name, arr)
        prefs(c).edit().putString("all", o.toString()).apply()
    }

    fun load(c: Context, name: String): List<Step> {
        val a = all(c).optJSONArray(name) ?: return emptyList()
        return (0 until a.length()).map { Step.fromJson(a.getJSONObject(it)) }
    }

    fun delete(c: Context, name: String) {
        val o = all(c); o.remove(name)
        prefs(c).edit().putString("all", o.toString()).apply()
    }
}
