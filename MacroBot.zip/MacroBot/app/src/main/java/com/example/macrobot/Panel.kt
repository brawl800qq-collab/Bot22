package com.example.macrobot

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.util.Random
import kotlin.math.abs
import kotlin.math.hypot

class Panel(private val svc: MacroService) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val F_PANEL = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    private val lp = WindowManager.LayoutParams(
        dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, F_PANEL, PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = dp(14); y = dp(100)
        softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
    }
    private val capLp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

    private lateinit var card: View
    private lateinit var bubble: View
    private var capView: View? = null
    private var cur: View? = null

    private lateinit var recBtn: TextView
    private lateinit var playBtn: TextView
    private lateinit var loopsEt: EditText
    private lateinit var jitterBox: CheckBox
    private lateinit var nameEt: EditText
    private lateinit var valueEt: EditText
    private lateinit var info: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var listBox: LinearLayout

    private var steps = ArrayList<Step>()
    private var recording = false
    @Volatile private var playing = false
    private var lastEnd = 0L

    init {
        card = buildCard()
        bubble = buildBubble()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * svc.resources.displayMetrics.density).toInt()
    private fun round(c: String, r: Int) = GradientDrawable().apply { setColor(Color.parseColor(c)); cornerRadius = dp(r).toFloat() }

    private fun chip(t: String, bg: String, onClick: () -> Unit) = TextView(svc).apply {
        text = t; setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8)); background = round(bg, 12); setOnClickListener { onClick() }
    }

    private fun field(hint: String, number: Boolean = false) = EditText(svc).apply {
        this.hint = hint; setHintTextColor(Color.parseColor("#77FFFFFF")); setTextColor(Color.WHITE); textSize = 13f
        setSingleLine(); setPadding(dp(10), dp(8), dp(10), dp(8)); background = round("#22FFFFFF", 12)
        inputType = if (number) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
    }

    private fun lpW(w: Int = -2, weight: Float = 0f, left: Int = 0, top: Int = 0) =
        LinearLayout.LayoutParams(if (weight > 0) 0 else w, -2, weight).apply { leftMargin = dp(left); topMargin = dp(top) }

    private fun row() = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun makeDraggable(handle: View, onTap: (() -> Unit)? = null) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); cur?.let { wm.updateViewLayout(it, lp) } }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    // ---------- UI ----------
    private fun buildBubble(): View = TextView(svc).apply {
        text = "⚡"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#00B894")) }
        makeDraggable(this) { swap(card) }
    }

    private fun buildCard(): View {
        val root = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = round("#F2151823", 22).apply { setStroke(dp(1), Color.parseColor("#44FFFFFF")) }
        }

        val header = row()
        header.addView(TextView(svc).apply {
            text = "⚡ Макро-бот"; setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD)
        }, lpW(weight = 1f))
        header.addView(chip("←", "#33FFFFFF") { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) }, lpW(left = 6))
        header.addView(chip("⌂", "#33FFFFFF") { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) }, lpW(left = 6))
        header.addView(chip("—", "#33FFFFFF") { swap(bubble) }, lpW(left = 6))
        makeDraggable(header)
        root.addView(header)

        // запись / воспроизведение
        val r1 = row()
        recBtn = chip("⏺ Запись", "#E5484D") { toggleRec() }
        playBtn = chip("▶ Играть", "#00B894") { togglePlay() }
        r1.addView(recBtn, lpW(weight = 1f)); r1.addView(playBtn, lpW(weight = 1f, left = 8))
        root.addView(r1, lpW(-1, top = 10))

        // повторы / случайность
        val r2 = row()
        r2.addView(TextView(svc).apply { text = "Повторов:"; setTextColor(Color.parseColor("#C9D1E0")); textSize = 13f }, lpW())
        loopsEt = field("0=∞", true).apply { setText("1") }
        r2.addView(loopsEt, lpW(dp(56) / dp(1) * 1, left = 6).apply { width = dp(56) })
        jitterBox = CheckBox(svc).apply { text = "🎲 рандом"; setTextColor(Color.parseColor("#C9D1E0")); textSize = 12f }
        r2.addView(jitterBox, lpW(left = 6))
        root.addView(r2, lpW(-1, top = 8))

        // сохранение / загрузка
        val r3 = row()
        nameEt = field("Название").apply { setText("Сценарий 1") }
        r3.addView(nameEt, lpW(weight = 1f))
        r3.addView(chip("💾", "#2A2F45") { saveMacro() }, lpW(left = 6))
        r3.addView(chip("📂", "#2A2F45") { toggleList() }, lpW(left = 6))
        root.addView(r3, lpW(-1, top = 8))

        listBox = LinearLayout(svc).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        root.addView(listBox, lpW(-1, top = 6))

        // ручное добавление шагов
        valueEt = field("текст кнопки или секунды")
        root.addView(valueEt, lpW(-1, top = 8))
        val r4 = row()
        r4.addView(chip("+ клик по тексту", "#2A2F45") { addText() }, lpW(weight = 1f))
        r4.addView(chip("+ пауза", "#2A2F45") { addWait() }, lpW(weight = 1f, left = 6))
        root.addView(r4, lpW(-1, top = 6))
        val r5 = row()
        r5.addView(chip("+ Назад", "#2A2F45") { addSimple("back") }, lpW(weight = 1f))
        r5.addView(chip("+ Домой", "#2A2F45") { addSimple("home") }, lpW(weight = 1f, left = 6))
        r5.addView(chip("🗑", "#2A2F45") { steps.clear(); updateInfo(); log("Сценарий очищен") }, lpW(left = 6))
        root.addView(r5, lpW(-1, top = 6))

        info = TextView(svc).apply { setTextColor(Color.WHITE); textSize = 12f; text = "Шагов: 0" }
        root.addView(info, lpW(-1, top = 8))

        logView = TextView(svc).apply {
            setTextColor(Color.parseColor("#9FB0C8")); textSize = 11f; typeface = Typeface.MONOSPACE
            text = "Нажми ⏺, делай тапы и свайпы, потом ⏹ и ▶.\n"
        }
        scroll = ScrollView(svc).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6)); background = round("#22000000", 12); addView(logView)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(80)).apply { topMargin = dp(6) })
        return root
    }

    private fun swap(to: View) {
        cur?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        if (to === bubble) { lp.width = dp(52); lp.height = dp(52) }
        else { lp.width = dp(310); lp.height = WindowManager.LayoutParams.WRAP_CONTENT }
        wm.addView(to, lp)
        cur = to
    }

    private fun setFocusable(f: Boolean) {
        lp.flags = if (f) F_PANEL else F_PANEL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        cur?.let { try { wm.updateViewLayout(it, lp) } catch (_: Exception) {} }
    }

    fun log(s: String) {
        svc.main.post {
            logView.append(s + "\n")
            if (logView.length() > 2000) logView.text = logView.text.takeLast(1500)
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun updateInfo() { info.text = "Шагов: ${steps.size}" }

    fun show() { swap(card) }

    fun hide() {
        playing = false
        if (recording) stopRec()
        cur?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cur = null
    }

    fun setHidden(h: Boolean) { cur?.alpha = if (h) 0f else 1f }

    // ---------- шаги ----------
    private fun nextDelay(): Long {
        val now = SystemClock.uptimeMillis()
        val d = if (recording && lastEnd > 0) (now - lastEnd).coerceAtMost(60000) else 500L
        lastEnd = now
        return d
    }

    private fun addSimple(type: String) {
        steps.add(Step(type, delay = nextDelay())); updateInfo(); log("+ $type")
    }

    private fun addText() {
        val t = valueEt.text.toString().trim()
        if (t.isEmpty()) { log("Впиши текст кнопки"); return }
        steps.add(Step("text", dur = 6000, delay = nextDelay(), text = t)); updateInfo(); log("+ клик по «$t»")
    }

    private fun addWait() {
        val sec = valueEt.text.toString().trim().toDoubleOrNull()
        if (sec == null || sec <= 0) { log("Впиши секунды, например 2.5"); return }
        steps.add(Step("wait", dur = (sec * 1000).toLong(), delay = 0)); updateInfo(); log("+ пауза $sec с")
    }

    // ---------- запись ----------
    private fun toggleRec() {
        if (playing) { log("Сначала останови воспроизведение"); return }
        if (recording) stopRec() else startRec()
    }

    private fun startRec() {
        steps.clear(); updateInfo()
        val (w, h) = svc.size()
        capLp.width = w; capLp.height = h
        capLp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        val v = View(svc).apply { setBackgroundColor(Color.parseColor("#12FF3B3B")) }
        attachCaptureTouch(v)
        capView = v
        wm.addView(v, capLp)
        // панель поверх слоя записи
        cur?.let { try { wm.removeView(it) } catch (_: Exception) {}; wm.addView(it, lp) }
        recording = true
        lastEnd = SystemClock.uptimeMillis()
        recBtn.text = "⏹ Стоп"
        log("⏺ Запись идёт. Делай тапы/свайпы")
    }

    private fun stopRec() {
        recording = false
        capView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        capView = null
        recBtn.text = "⏺ Запись"
        updateInfo()
        log("⏹ Записано шагов: ${steps.size}")
    }

    private fun setCapTouchable(t: Boolean) {
        val v = capView ?: return
        capLp.flags = if (t)
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        else
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, capLp) } catch (_: Exception) {}
    }

    private fun attachCaptureTouch(v: View) {
        var dx = 0f; var dy = 0f; var lx = 0f; var ly = 0f; var t0 = 0L
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; lx = dx; ly = dy; t0 = SystemClock.uptimeMillis() }
                MotionEvent.ACTION_MOVE -> { lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_UP -> {
                    lx = e.rawX; ly = e.rawY
                    val t1 = SystemClock.uptimeMillis()
                    val (w, h) = svc.size()
                    val dist = hypot(lx - dx, ly - dy)
                    val delay = if (steps.isEmpty()) 300L else (t0 - lastEnd).coerceIn(0, 60000)
                    lastEnd = t1
                    val p = Path()
                    val step: Step
                    val dur: Long
                    if (dist < dp(12)) {
                        dur = (t1 - t0).coerceIn(40, 1500)
                        step = Step("tap", dx / w, dy / h, dur = dur, delay = delay)
                        p.moveTo(dx, dy)
                    } else {
                        dur = (t1 - t0).coerceIn(120, 2500)
                        step = Step("swipe", dx / w, dy / h, lx / w, ly / h, dur = dur, delay = delay)
                        p.moveTo(dx, dy); p.lineTo(lx, ly)
                    }
                    steps.add(step); updateInfo()
                    // пробрасываем жест в приложение под слоем записи
                    setCapTouchable(false)
                    svc.gestureAsync(p, dur) { svc.main.post { setCapTouchable(true) } }
                }
            }
            true
        }
    }

    // ---------- воспроизведение ----------
    private fun togglePlay() {
        if (playing) { playing = false; log("■ Останавливаю…"); return }
        if (recording) stopRec()
        if (steps.isEmpty()) { log("Сценарий пуст. Запиши его ⏺"); return }
        val loops = loopsEt.text.toString().toIntOrNull() ?: 1
        val jitter = jitterBox.isChecked
        val list = ArrayList(steps)
        setFocusable(false)
        playBtn.text = "■ Стоп"; playBtn.background = round("#E5484D", 12)
        play(list, loops, jitter)
    }

    private fun sleepP(ms: Long) {
        var t = 0L
        while (playing && t < ms) { val s = minOf(100L, ms - t); Thread.sleep(s); t += s }
    }

    private fun play(list: List<Step>, loops: Int, jitter: Boolean) {
        playing = true
        Thread {
            val rnd = Random()
            var n = 0
            try {
                while (playing && (loops == 0 || n < loops)) {
                    n++
                    log("↻ цикл $n" + if (loops > 0) "/$loops" else "")
                    for (s in list) {
                        if (!playing) break
                        var d = s.delay
                        if (jitter) d = (d * (0.85 + rnd.nextDouble() * 0.3)).toLong()
                        sleepP(d)
                        if (!playing) break
                        exec(s, jitter, rnd)
                    }
                }
            } catch (e: Exception) { log("❌ ${e.message}") }
            playing = false
            svc.main.post {
                playBtn.text = "▶ Играть"; playBtn.background = round("#00B894", 12)
                setFocusable(true)
                log("■ Готово")
            }
        }.start()
    }

    private fun exec(s: Step, jitter: Boolean, rnd: Random) {
        val (w, h) = svc.size()
        val j = if (jitter) (rnd.nextFloat() - 0.5f) * dp(8) else 0f
        when (s.type) {
            "tap" -> { val p = Path(); p.moveTo(s.x1 * w + j, s.y1 * h + j); svc.gestureSync(p, s.dur) }
            "swipe" -> {
                val p = Path(); p.moveTo(s.x1 * w + j, s.y1 * h + j); p.lineTo(s.x2 * w + j, s.y2 * h + j)
                svc.gestureSync(p, s.dur)
            }
            "back" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            "wait" -> sleepP(s.dur)
            "text" -> {
                val end = SystemClock.uptimeMillis() + s.dur
                var ok = false
                while (playing && SystemClock.uptimeMillis() < end) {
                    if (svc.clickText(s.text)) { ok = true; break }
                    sleepP(500)
                }
                if (!ok && playing) log("не найден «${s.text}», пропуск")
            }
        }
    }

    // ---------- сохранение ----------
    private fun saveMacro() {
        val name = nameEt.text.toString().trim()
        if (name.isEmpty()) { log("Впиши название"); return }
        if (steps.isEmpty()) { log("Нечего сохранять"); return }
        Store.save(svc, name, steps); log("💾 Сохранено: $name")
    }

    private fun toggleList() {
        if (listBox.visibility == View.VISIBLE) { listBox.visibility = View.GONE; return }
        listBox.removeAllViews()
        val names = Store.names(svc)
        if (names.isEmpty()) listBox.addView(TextView(svc).apply {
            text = "Сохранённых нет"; setTextColor(Color.parseColor("#9FB0C8")); textSize = 12f
        })
        names.forEach { nm ->
            val c = chip("📄 $nm  (удерж. = удалить)", "#2A2F45") {
                steps = ArrayList(Store.load(svc, nm)); nameEt.setText(nm); updateInfo()
                listBox.visibility = View.GONE; log("Загружено: $nm (${steps.size} шагов)")
            }
            c.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            c.setOnLongClickListener {
                Store.delete(svc, nm); log("Удалён: $nm"); listBox.visibility = View.GONE; true
            }
            listBox.addView(c, lpW(-1, top = 4))
        }
        listBox.visibility = View.VISIBLE
    }
}
