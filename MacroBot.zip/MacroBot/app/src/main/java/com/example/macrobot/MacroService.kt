package com.example.macrobot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class MacroService : AccessibilityService() {
    companion object {
        @Volatile var instance: MacroService? = null
    }

    val main = Handler(Looper.getMainLooper())
    var panel: Panel? = null

    override fun onServiceConnected() {
        instance = this
        panel = Panel(this).also { it.show() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        panel?.hide(); panel = null; instance = null
        return super.onUnbind(intent)
    }

    fun size(): Pair<Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.maximumWindowMetrics.bounds
        return Pair(b.width(), b.height())
    }

    private fun findRoot(): AccessibilityNodeInfo? {
        val sorted = windows
            .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .sortedWith(compareByDescending<AccessibilityWindowInfo> { it.isActive }.thenByDescending { it.layer })
        for (w in sorted) {
            val r = w.root ?: continue
            if (r.packageName?.toString() != packageName) return r
        }
        val a = rootInActiveWindow
        return if (a != null && a.packageName?.toString() != packageName) a else null
    }

    /** Вызывать НЕ из главного потока: ждёт окончания жеста. */
    fun gestureSync(p: Path, dur: Long) {
        val latch = CountDownLatch(1)
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur.coerceAtLeast(1))).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { latch.countDown() }
            override fun onCancelled(gestureDescription: GestureDescription?) { latch.countDown() }
        }, main)
        if (ok) latch.await(dur + 2000, TimeUnit.MILLISECONDS)
    }

    /** Можно из главного потока: по завершении вызывает done. */
    fun gestureAsync(p: Path, dur: Long, done: () -> Unit) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, dur.coerceAtLeast(1))).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done() }
        }, main)
        if (!ok) done()
    }

    /** Найти на экране элемент по тексту / описанию и нажать. */
    fun clickText(text: String): Boolean {
        val root = findRoot() ?: return false
        val n = root.findAccessibilityNodeInfosByText(text).firstOrNull { it.isVisibleToUser } ?: return false
        var x: AccessibilityNodeInfo? = n
        var d = 0
        while (x != null && d < 5) {
            if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            x = x.parent; d++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        val p = Path()
        p.moveTo(r.exactCenterX(), r.exactCenterY())
        gestureSync(p, 50)
        return true
    }
}
