# Макро-бот (Android, без ИИ)
Сборка: загрузить в GitHub → Actions → Build APK → скачать artifact MacroBot-apk. Либо Android Studio → Build APK.
Запуск: включить «Макро-бот» в Специальных возможностях → появится окно ⚡.
